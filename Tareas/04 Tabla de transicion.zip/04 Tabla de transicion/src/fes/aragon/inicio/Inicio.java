package fes.aragon.inicio;

import fes.aragon.herramientas.Archivos;

public class Inicio {

	public static void main(String[] args) {

		Archivos archivo = new Archivos();
		archivo.analizarPalabras();
		

		
		
	}

}
